package TestyBdd.StepDefinitions;

import TestyBdd.Pages.ContactPage;
import TestyBdd.Pages.HomePage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;

public class ContactPageSteps {

    ContactPage contactPage = new ContactPage();


    @Then("User is on Contact Page")
    public void user_is_on_contact_page() {
        String contactName = contactPage.getContactString();
        Assertions.assertEquals("Contact", contactName);

    }
}
