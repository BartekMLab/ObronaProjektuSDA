package TestyBdd.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ContactPage extends BasePage {


    @FindBy(how = How.XPATH, using = "//main/h1")
    WebElement contactString;

    public String getContactString(){
        new WebDriverWait(driver,10).until(ExpectedConditions.visibilityOf(contactString));
        return contactString.getText();
    }

}
